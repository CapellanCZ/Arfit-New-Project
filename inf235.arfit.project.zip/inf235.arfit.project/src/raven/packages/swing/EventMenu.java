package raven.packages.swing;

public interface EventMenu {

    public void selected(int index);

    public void menuSelected(int index);
}
