package raven.packages.swing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import net.miginfocom.swing.MigLayout;

public class Menu extends javax.swing.JPanel {

    private List<EventMenu> events;

    public Menu() {
        initComponents();
        setOpaque(false);
        events = new ArrayList<>();
        jPanel1.setLayout(new MigLayout("wrap, fill, inset 0", "[center]", "[center]"));
        addSpace(20);
        addItem("1", 0);
        addItem("2", 1);
        addItem("3", 2);
        addItem("4", 3);
        addItem("5", 4);
        addItem("6", 5);
        addItem("7", 6);
        addSpace(20);
        repaint();
        revalidate();
    }

    private void addSpace(int size) {
        jPanel1.add(new JLabel(), "h " + size + "!");
    }

    private void addItem(String icon, int index) {
        MenuItem item = new MenuItem();
        item.setImage(new ImageIcon(getClass().getResource("/icon/" + icon + ".png")).getImage());
        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                runEvent(index);
            }
        });
        jPanel1.add(item, "w 50!, h 50!");
    }

    public void addEvent(EventMenu event) {
        events.add(event);
    }

    private void runEvent(int index) {
        for (EventMenu event : events) {
            event.menuSelected(index);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 112, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 618, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
